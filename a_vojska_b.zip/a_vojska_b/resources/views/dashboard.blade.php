<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Pregled') }}
        </h2>
    </x-slot>
    <?php 

    $categories = DB::select(DB::raw('SELECT cat.name,post.title,post.post_text,post.ukup_ubojitost FROM categories cat,posts post WHERE cat.id = post.category_id order by cat.name,post.title'));
    $uk_categ = DB::select(DB::raw('SELECT cat.name,sum(post.ukup_ubojitost) ukup_ubojitost FROM categories cat,posts post WHERE cat.id = post.category_id GROUP by cat.name'));
    $sve_uk = DB::select(DB::raw('SELECT "Vojska A" grupa,sum(post.ukup_ubojitost) ukup_ubojitost FROM categories cat,posts post WHERE cat.id = post.category_id and cat.name LIKE "%A" UNION SELECT "Vojska B" grupa,sum(post.ukup_ubojitost) ukup_ubojitost FROM categories cat,posts post WHERE cat.id = post.category_id and cat.name LIKE "%B"  ORDER BY ukup_ubojitost DESC'));
    ?>
    
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200" style="background-color:	#a67c00">
<!--tablica pregleda-->

<table  table-layout:fixed>
    <thead>
        <tr>
            <th width="50%" >Vojska</th>
            <th width="50%" style="background-color:#ffdc73" >Ubojitost</th>
        </tr>
    </thead>
    <tbody>
        @foreach($sve_uk as $sve_u)
        <tr style="text-align:center">
            <td width="50%">{{$sve_u->grupa}}</td>
            <td  width="50%" style="background-color:#ffdc73" >{{$sve_u->ukup_ubojitost}}</td>
               
            @csrf
            </form>
            </td>
        </tr>
       @endforeach
    </tbody>
</table>
</div>
</div>
</div>
</div>
<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 bg-white border-b border-gray-200" style="background-color:#bf9b30">
<!--tablica pregleda-->

<table  table-layout:fixed>
<thead>
    <tr>
        <th width="50%" >Rod Vojske</th>
        <th width="50%" style="background-color:#ffdc73">Ubojitost</th>
    </tr>
</thead>
<tbody>
    @foreach($uk_categ as $uk_cat)
    <tr style="text-align:center">
        <td width="50%">{{$uk_cat->name}}</td>
        <td  width="50%" style="background-color:#ffdc73">{{$uk_cat->ukup_ubojitost}}</td>
           
        @csrf
        </form>
        </td>
    </tr>
   @endforeach
</tbody>
</table>
</div>
</div>
</div>
</div>
<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 bg-white border-b border-gray-200" style="background-color:#ffbf00">

<table  table-layout:fixed>
    <thead>
        <tr>
            <th width="25%" >Rod Vojske</th>
            <th width="25%" >Oružje</th>
            <th width="25%" style="text-align:center">Količina</th>
            <th width="25%" style="text-align:center;background-color:#ffdc73">Ubojitost</th>
        </tr>
    </thead>
    <tbody>
        @foreach($categories as $category)
        <tr style="text-align:center">
            <td width="25%">{{$category->name}}</td>
            <td  width="25%" >{{$category->title}}</td>
            <td width="25%">{{$category->post_text}}</td>
            <td  width="25%" style="background-color:#ffdc73">{{$category->ukup_ubojitost}}</td>
               
            @csrf
            </form>
            </td>
        </tr>
       @endforeach
    </tbody>
</table>


<!--kraj tablice-->
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
