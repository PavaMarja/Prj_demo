<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Rodovi Vojske') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200" >
                    <a href="{{ route('categories.create') }}" style="color:blue">Dodaj novu vojsku</a>
                    <br /><br />
                    <table table-layout:fixed>
                        <thead>
                            <tr style="text-align:center">
                                <th width="50%">Rod vojske</th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th width="50%"></th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($categories as $category)
                            <tr style="text-align:center">
                                <td>{{ $category->name }}</td>
                                <td>
                                    <a href="{{ route('categories.edit', $category) }}" style="color:blue">Promjena</a>
                                    <form method="POST" action="{{ route('categories.destroy', $category) }}">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" onclick="return confirm('Jeste li sigurni?')" style="color:red">Brisanje</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
