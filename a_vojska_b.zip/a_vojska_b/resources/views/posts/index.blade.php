<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Rod Vojske i Oružja') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <a href="{{ route('posts.create') }}" style="color:blue">Dodaj</a>
                    <br /><br />
                    <table table-layout:fixed>
                        <thead>
                            <tr style="text-align:center">
                                <th width="25%">Rod Vojske</th>
                                <th width="25%">Oružje</th>
                                <th width="25%">Količina</th>
                                <th width="25%">Ubojitost</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($posts as $post)
                            <tr style="text-align:center">
                                <td>{{ $post->category->name }}</td>
                                <td>{{ $post->title }}</td>
                                <td>{{ $post->post_text }}</td>
                                <td>{{ $post->ukup_ubojitost }}</td>
                                <td>
                                    <a href="{{ route('posts.edit', $post) }}" style="color:blue">Promjena</a>
                                    <form method="POST" action="{{ route('posts.destroy', $post) }}">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" onclick="return confirm('Jeste li sigurni?')" style="color:red">Brisanje</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
